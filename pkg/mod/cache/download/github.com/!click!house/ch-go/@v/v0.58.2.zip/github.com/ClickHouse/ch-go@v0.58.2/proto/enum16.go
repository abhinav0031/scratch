package proto

// Enum16 represents raw Enum16 value.
//
// Actual values should be taken from DDL.
type Enum16 int16
