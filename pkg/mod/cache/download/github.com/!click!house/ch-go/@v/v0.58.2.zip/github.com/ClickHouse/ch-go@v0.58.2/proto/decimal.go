package proto

// Decimal32 represents Decimal32 value.
type Decimal32 int32

// Decimal64 represents Decimal32 value.
type Decimal64 int64

// Decimal128 represents Decimal128 value.
type Decimal128 Int128

// Decimal256 represents Decimal256 value.
type Decimal256 Int256
