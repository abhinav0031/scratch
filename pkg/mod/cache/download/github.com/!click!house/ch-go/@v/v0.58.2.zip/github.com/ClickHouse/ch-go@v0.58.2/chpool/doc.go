// Package chpool is a connection pool for ch.
package chpool
