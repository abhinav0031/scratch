// Package proto implements ClickHouse wire protocol.
package proto

// Defaults for ClientHello.
const (
	Version = 54460
	Name    = "clickhouse/ch-go"
)
