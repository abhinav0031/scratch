// Package cht implements running ClickHouse for tests.
package cht
