# mssql-always-encrypted

A library to interact with MSSQL's Always Encrypted features.
This library mostly handles the crpyto part to facilitate
the integration with [go-mssql](https://github.com/denisenkom/go-mssqldb).