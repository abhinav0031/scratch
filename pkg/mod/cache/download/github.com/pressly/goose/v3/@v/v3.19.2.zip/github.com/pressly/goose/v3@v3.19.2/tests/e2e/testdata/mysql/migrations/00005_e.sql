-- +goose Up
-- +goose StatementBegin
-- NOTE: intentionally left blank to verify migration logic.
SELECT 'up SQL query';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- NOTE: intentionally left blank to verify migration logic.
SELECT 'down SQL query';
-- +goose StatementEnd
