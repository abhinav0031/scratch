CREATE TABLE post (
	id int NOT NULL,
	title text,
	foo text,
	footitle3 text,
	defaulttitle4 text,
	title5 text,
);