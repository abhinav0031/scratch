INSERT INTO post (id, title, body)
VALUES ('id_01', 'my_title', '
this is an insert statement including empty lines.

empty (blank) lines can be meaningful.

leave the lines to keep the text syntax.
');